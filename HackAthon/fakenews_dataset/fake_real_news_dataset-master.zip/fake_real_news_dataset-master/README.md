# fake_real_news_dataset

This is the repo hosting the data for my fake vs real news project. The data is in a zipped csv file and contains 1000s of articles tagged as either real or fake. 
